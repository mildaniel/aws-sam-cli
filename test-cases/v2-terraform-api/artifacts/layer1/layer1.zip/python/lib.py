import boto3

def get_const():
    return 1